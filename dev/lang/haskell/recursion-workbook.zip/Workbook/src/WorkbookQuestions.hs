module WorkbookQuestions where

import qualified Data.Map as M

evens :: [a] -> [a]
evens = error "evens not implemented"

addWhenMod3Is2 :: [Int] -> [Int]
addWhenMod3Is2 = error "addWhenMod3Is2 not implemented"

reverse_ :: [a] -> [a]
reverse_ = error "reverse_ not implemented"

reverseAccum :: [a] -> [a]
reverseAccum = error "reverseAccum not implemented"

specialMultiples :: [Int] -> [Int]
specialMultiples = error "specialMultiples not implemented"

manyStrings :: [Int] -> [String] -> [String]
manyStrings = error "manyStrings not implemented"

addPairs :: [Int] -> [Int]
addPairs = error "addPairs not implemented"

listToMap :: [Int] -> M.Map String Int
listToMap = error "listToMap not implemented"

sumWithParity :: [Int] -> Int
sumWithParity = error "sumWithParity not implemented" 

jumpingStairs :: [Int] -> [(String, Int)] -> ([String], [String])
jumpingStairs = error "jumpingStairs not implemented"
